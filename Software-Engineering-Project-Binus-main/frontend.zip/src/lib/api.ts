const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3001";

export async function postData(
  endpoint: string,
  body: any
) {
  const response = await fetch(`${API_URL}/${endpoint}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.message || "Request failed");
  }

  return data;
}