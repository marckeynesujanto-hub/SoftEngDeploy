export default function TrackingPage() {
    const steps = ["Pesanan Diterima", "Driver Menuju Lokasi", "Sampah Diambil", "Selesai"];
    const currentStep = 1; // Contoh: Driver sedang menuju lokasi
  
    return (
      <div className="p-6 bg-gray-50 min-h-screen">
        <h2 className="text-2xl font-bold mb-6">Tracking Penjemputan</h2>
        <div className="bg-white p-6 rounded-3xl shadow-sm">
          {steps.map((step, index) => (
            <div key={index} className="flex items-center mb-4">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${index <= currentStep ? 'bg-teal-700 text-white' : 'bg-gray-200'}`}>
                {index + 1}
              </div>
              <div className={`ml-4 font-semibold ${index <= currentStep ? 'text-teal-700' : 'text-gray-400'}`}>
                {step}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }