"use client";

import Image from "next/image";
import Link from "next/link";
import {
  Home,
  Percent,
  Settings,
  Wallet,
  History,
  MoreHorizontal,
} from "lucide-react";

export default function DashboardPage() {
  useEffect(() => {
    fetch("http://localhost:5000/api/wallet")
      .then((res) => res.json())
      .then((data) => setBalance(data.balance));
  }, []);

  const services = [
    {
      name: "TrashDeal",
      icon: "🚛",
      href: "/trashdeal",
    },
    {
      name: "TrashOut",
      icon: "🧍",
      href: "/trashout",
    },
    {
      name: "TrashMaps",
      icon: "📍",
      href: "/trashmaps",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-100 pb-24">
      {/* HEADER */}
      <div
        className="h-48 bg-cover bg-center rounded-b-3xl p-4"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1500530855697-b586d89ba3ee')",
        }}
      >
        <div className="flex items-center gap-3">
          <input
            type="text"
            placeholder="Find services or places..."
            className="flex-1 bg-white rounded-full px-4 py-2 shadow"
          />

          <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center">
            👤
          </div>
        </div>
      </div>

      {/* BALANCE CARD */}
      <div className="px-4 -mt-12">
        <div className="bg-green-600 text-white rounded-3xl p-5 shadow-lg">
          <p className="text-sm opacity-90">
            Available balance
          </p>

          <h2 className="text-2xl font-bold mt-1">
            Rp. {balance.toLocaleString("id-ID")}
          </h2>

          <div className="grid grid-cols-3 gap-3 mt-5">
            <button className="bg-white text-black rounded-xl py-2 flex justify-center items-center gap-2">
              <Wallet size={18} />
              Pay
            </button>

            <button className="bg-white text-black rounded-xl py-2 flex justify-center items-center gap-2">
              <History size={18} />
              History
            </button>

            <button className="bg-white text-black rounded-xl py-2 flex justify-center items-center gap-2">
              <MoreHorizontal size={18} />
              More
            </button>
          </div>
        </div>
      </div>

      {/* SERVICES */}
      <div className="px-4 mt-5">
        <div className="grid grid-cols-3 gap-4">
          {services.map((service) => (
            <Link
              href={service.href}
              key={service.name}
              className="bg-white rounded-2xl p-4 text-center shadow"
            >
              <div className="text-4xl mb-2">
                {service.icon}
              </div>

              <p className="font-medium text-sm">
                {service.name}
              </p>
            </Link>
          ))}
        </div>
      </div>

      {/* PROMO BANNER */}
      <div className="px-4 mt-5">
        <div className="bg-lime-400 rounded-2xl p-4 overflow-hidden">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="font-bold text-lg">
                Enjoy the lowest price
              </h3>

              <p className="text-sm mt-1">
                for your plan!
              </p>

              <button className="bg-black text-white px-4 py-2 rounded-lg mt-3">
                Get Plus+
              </button>
            </div>

            <div className="text-6xl">
              🔫
            </div>
          </div>
        </div>
      </div>

      {/* SUBSCRIPTION CARD */}
      <div className="px-4 mt-4">
        <div className="bg-lime-400 rounded-2xl p-4">
          <p className="text-sm">
            Get free 2 weeks!
          </p>

          <h2 className="text-3xl font-bold">
            2 WEEKS+
          </h2>

          <button className="mt-3 bg-black text-white px-4 py-2 rounded-lg">
            Subscribe Now
          </button>
        </div>
      </div>

      {/* BOTTOM NAVBAR */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg">
        <div className="flex justify-around py-3">
          <Link href="/dashboard">
            <Home size={24} />
          </Link>

          <Link href="/voucher">
            <Percent size={24} />
          </Link>

          <Link href="/wallet">
            <Wallet size={24} />
          </Link>

          <Link href="/settings">
            <Settings size={24} />
          </Link>
        </div>
      </nav>
    </div>
  );
}