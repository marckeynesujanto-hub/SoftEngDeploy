"use client";

import { useState } from "react";
import Link from "next/link";
import { FaRegEnvelope } from "react-icons/fa";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(e.target.value);
    // Hapus pesan status jika user mulai mengetik lagi
    if (statusMessage) setStatusMessage(null);
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    setStatusMessage(null);

    console.log("Meminta reset password untuk:", email);

    try {
      // DATA-DRIVEN: Simulasi pemanggilan API ke backend
      /* const response = await fetch("http://localhost:5000/api/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Gagal mengirim link reset");
      */

      await new Promise((resolve) => setTimeout(resolve, 1500)); // Simulasi delay

      // Jika sukses
      setStatusMessage({
        type: 'success',
        text: "Reset link has been sent to your email. Please check your inbox."
      });
      setEmail(""); // Kosongkan input setelah berhasil

    } catch (err) {
      // Jika gagal
      setStatusMessage({
        type: 'error',
        text: err instanceof Error ? err.message : "Terjadi kesalahan, coba lagi."
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-white text-black p-4 sm:p-8 font-serif">
      
      {/* Container di-set max-w-[400px] agar konsisten dengan halaman Login/Register */}
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-[400px] flex flex-col items-center"
      >
        <h1 className="text-3xl sm:text-4xl font-bold mb-2 tracking-wide uppercase text-center">
          FORGOT PASSWORD
        </h1>
        
        <p className="text-sm sm:text-base text-center text-gray-700 mb-6 px-4">
          Enter your registered email address to receive a password reset link.
        </p>

        {/* Tampilan Status (Error atau Sukses) */}
        {statusMessage && (
          <div 
            className={`w-full mb-4 p-3 border text-sm text-center ${
              statusMessage.type === 'success' 
                ? 'bg-green-50 border-green-600 text-green-800' 
                : 'bg-red-50 border-red-500 text-red-700'
            }`}
          >
            {statusMessage.text}
          </div>
        )}

        {/* INPUT EMAIL KOTAK */}
        <div className="w-full flex flex-col gap-0 mb-4">
          <div className="relative w-full border border-black flex items-center bg-white">
            <div className="w-10 flex justify-center items-center py-2">
              <FaRegEnvelope className="text-black" />
            </div>
            <input
              type="email"
              name="email"
              placeholder="Enter your email"
              value={email}
              onChange={handleInputChange}
              required
              className="w-full py-2 px-2 outline-none bg-transparent text-sm sm:text-base"
            />
          </div>
        </div>

        {/* TOMBOL SUBMIT */}
        <button
          type="submit"
          disabled={isLoading || !email}
          className="w-full border border-black bg-gray-100 py-2 hover:bg-gray-200 transition-colors text-black text-sm sm:text-base disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? "Sending..." : "Send Reset Link"}
        </button>

        {/* LINK KEMBALI KE LOGIN */}
        <div className="text-sm sm:text-base text-center mt-6">
          Remember your password?
          <Link
            href="/login"
            className="text-purple-800 underline ml-1 hover:text-purple-600"
          >
            Back to Login
          </Link>
        </div>
      </form>
    </div>
  );
}