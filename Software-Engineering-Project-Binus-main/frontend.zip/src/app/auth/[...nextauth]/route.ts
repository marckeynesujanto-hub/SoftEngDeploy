import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials"; 
import GoogleProvider from "next-auth/providers/google";
import AppleProvider from "next-auth/providers/apple";

const handler = NextAuth({
  providers: [
    // 1. Provider Sosial (Google & Apple)
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID as string,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET as string,
    }),
    AppleProvider({
      clientId: process.env.APPLE_ID as string,
      clientSecret: process.env.APPLE_SECRET as string,
    }),

    // 2. Provider Login Manual (Email & Password)
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "text" },
        password: { label: "Password", type: "password" }
      },
      async authorize(credentials) {
        try {
          // Ambil URL dari .env.local (default ke 3001 jika kosong)
          const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3001/api";
          
          const res = await fetch(`${apiUrl}/login`, {
            method: 'POST',
            body: JSON.stringify(credentials),
            headers: { "Content-Type": "application/json" }
          });
          
          const user = await res.json();
          
          // Jika backend bilang OK dan data user ada, login sukses
          if (res.ok && user) {
            return user;
          }
          
          return null; // Login gagal
        } catch (error) {
          console.error("Gagal koneksi ke backend saat login:", error);
          return null; 
        }
      }
    })
  ],
  pages: {
    signIn: '/login', // Arahkan ke halaman login buatan kita
  },
  session: {
    strategy: "jwt",
  }
});

export { handler as GET, handler as POST };