"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { signIn } from "next-auth/react";
import { FcGoogle } from "react-icons/fc";
import { postData } from "@/lib/api";
import {
  FaEnvelope,
  FaLock,
  FaEye,
  FaEyeSlash,
  FaApple,
  FaWindows,
} from "react-icons/fa";

export default function LoginPage() {
  const router = useRouter();

  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const socialProviders = [
    {
      id: "google",
      name: "Google",
      icon: <FcGoogle className="text-xl" />,
    },
    {
      id: "apple",
      name: "Apple",
      icon: <FaApple className="text-xl" />,
    },
    {
      id: "microsoft",
      name: "Microsoft",
      icon: <FaWindows className="text-xl" />,
    },
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    setIsLoading(true);
    setError("");

    try {
      const data = await postData("login", formData);

      if (data?.token) {
        localStorage.setItem("authToken", data.token);
      }

      router.push("/dashboard");
    } catch (err: any) {
      setError(err?.message || "Login gagal");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSocialLogin = async (providerId: string) => {
    await signIn(providerId, {
      callbackUrl: "/dashboard",
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-white text-black p-4">
      <form
        onSubmit={handleLogin}
        className="w-full max-w-[400px] flex flex-col"
      >
        <h1 className="text-3xl font-bold text-center mb-6 uppercase">
          LOGIN
        </h1>

        {error && (
          <div className="mb-4 p-3 bg-red-100 border border-red-500 text-red-700 rounded text-center">
            {error}
          </div>
        )}

        <div className="flex flex-col">
          <div className="border border-black flex items-center">
            <div className="w-10 flex justify-center">
              <FaEnvelope />
            </div>

            <input
              type="email"
              name="email"
              placeholder="Email"
              value={formData.email}
              onChange={handleChange}
              required
              className="w-full py-2 px-2 outline-none"
            />
          </div>

          <div className="border border-black flex items-center -mt-[1px]">
            <div className="w-10 flex justify-center">
              <FaLock />
            </div>

            <input
              type={showPassword ? "text" : "password"}
              name="password"
              placeholder="Password"
              value={formData.password}
              onChange={handleChange}
              required
              className="w-full py-2 px-2 outline-none"
            />

            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="px-3"
            >
              {showPassword ? <FaEyeSlash /> : <FaEye />}
            </button>
          </div>
        </div>

        <button
          type="submit"
          disabled={isLoading}
          className="w-full border border-black py-2 mt-3 hover:bg-gray-100 disabled:opacity-50"
        >
          {isLoading ? "Loading..." : "Login"}
        </button>

        <div className="text-center mt-4 mb-2">
          or continue with
        </div>

        <div className="flex flex-col">
          {socialProviders.map((provider) => (
            <button
              key={provider.id}
              type="button"
              onClick={() => handleSocialLogin(provider.id)}
              className="w-full border border-black py-2 flex items-center justify-center gap-2 -mt-[1px]"
            >
              {provider.icon}
              Continue with {provider.name}
            </button>
          ))}
        </div>

        <div className="text-center mt-4">
          Don't have an account?
          <Link
            href="/register"
            className="ml-1 text-purple-700 underline"
          >
            Register here
          </Link>
        </div>
      </form>
    </div>
  );
}